# data preprocessing, exploratory analysis and smote + standardization
library(DMwR)
library(caTools)
library(dplyr)
library(ggplot2)
library(ggthemes)
library(RColorBrewer)

loan = read_csv("~/Desktop/loan_data_2007_2014.csv")
loan = loan %>%
  select(loan_status, loan_amnt , term , int_rate , installment , grade , emp_length , home_ownership,annual_inc, dti, purpose,installment )
loan

loan$term <- gsub('months', '', loan$term)
loan$emp_length <- gsub('>', '', loan$emp_length)
loan$emp_length <- gsub('<', '', loan$emp_length)
loan$emp_length <- gsub('10+', '10', loan$emp_length)
loan$emp_length <- gsub('years', '', loan$emp_length)
loan$emp_length <- gsub('year', '', loan$emp_length)
loan$emp_length<-str_replace_all(loan$emp_length, fixed("10+"), "10")
loan$emp_length<- str_replace_all(loan$emp_length,  fixed(" "), "")

loan %>%
  group_by(loan_status) %>%
  summarize(freq = n()) %>%
  ggplot(aes(reorder(loan_status, freq), y = freq, fill = freq)) +   
  geom_bar(stat = "identity", position = "dodge", width=0.4) +
  xlab("Loan Status") +
  ylab("Frequency") +
  theme_fivethirtyeight() + 
  coord_flip() +
  theme(legend.position ='none', axis.text.x = element_text(size = 3)) + 
  scale_fill_gradientn(name = '',colours = rev(brewer.pal(11,'Spectral'))) +
  ggtitle("Loan Status")

loan <- loan %>%
  mutate(loan_outcome = ifelse(loan_status %in% c('Charged Off' , 'Default', 'Late (16-30 days)','Late (31-120 days)','In Grace Period') , 0, 
                               ifelse(loan_status == 'Fully Paid' , 1 , 'No info')))
loan <- loan %>%select(-loan_status) %>%filter(loan_outcome %in% c(0 , 1))

loan %>%
  group_by(loan_outcome) %>%
  summarize(freq = n()) %>%
  ggplot(aes(reorder(loan_outcome, freq), y = freq, fill = freq)) +   
  geom_bar(stat = "identity", position = "dodge", width=0.4) +
  xlab("Loan outcome") +
  ylab("Frequency") +
  theme_fivethirtyeight() + 
  coord_flip() +
  theme(legend.position ='none', axis.text.x = element_text(size = 3)) + 
  scale_fill_gradientn(name = '',colours = rev(brewer.pal(11,'Spectral'))) +
  ggtitle("Loan outcome")

loan$emp_length<-as.numeric(loan$emp_length)
for(i in 1:nrow(loan)){
  loan$emp_length[i][is.na(loan$emp_length[i])] <- round(mean(loan$emp_length, na.rm = TRUE))
}
anyNA(loan$emp_length)

by_grade <- table(loan$loan_outcome, loan$grade, exclude="")
prop_grade <- prop.table(by_grade,2)
barplot(prop_grade, main = "Loan Performance by Grade", xlab = "Grade", 
        col=c("darkblue","darkred"), legend = rownames(prop_grade))

ggplot(loan[sample(244179 , 10000) , ] , aes(x = annual_inc , y = loan_amnt , color = int_rate)) +
  geom_point(alpha = 0.5 , size = 1.5) + 
  geom_smooth(se = F , color = 'darkred' , method = 'loess') +
  xlim(c(0 , 300000)) + 
  labs(x = 'Annual Income' , y = 'Loan Ammount' , color = 'Interest Rate')

ggplot(loan, aes(x=loan_amnt,fill=grade))+
  geom_density(alpha = 0.5) + 
  theme(legend.position="none") +
  theme_fivethirtyeight() + 
  xlab("Loan Amount") + 
  ggtitle("Loan Amount by Borrower's Grade") + 
  facet_grid(grade ~ .)

ggplot(loan , aes(group = grade, x = grade , y = int_rate , fill = grade)) + 
  geom_boxplot() + 
  theme_igray() + 
  labs(y = 'Interest Rate' , x = 'Grade')

unbalanced_data$home_ownership <- factor(unbalanced_data$home_ownership)
unbalanced_data$purpose <- factor(unbalanced_data$purpose)
unbalanced_data$loan_outcome <- factor(unbalanced_data$loan_outcome)
train_data$home_ownership <- factor(train_data$home_ownership)
train_data$purpose <- factor(train_data$purpose)
train_data$loan_outcome <- factor(train_data$loan_outcome,
                                  train_data =train_data[,-14][,-13])
                                  
balanced.train_data <-DMwR::SMOTE(form = loan_outcome ~ .,
                                  data = train_data,
                                  perc.over = 100,
                                  perc.under = 200)

loan_new$loan_amnt = (loan$loan_amnt - mean(loan$loan_amnt))/var(loan$loan_amnt)
loan_new$term = (loan$term - mean(loan$term))/var(loan$term)
loan_new$int_rate = (loan$int_rate - mean(loan$int_rate))/var(loan$int_rate)
apply(loan_new[,2:3], 2, var)
loan_new[,2:3]= (loan[,2:3]-mean(loan[,2:3]))/var(loan[,2:3])
quantitative_data = cbind(loan[,2:7],loan[,9:10])
quantitative_data = (quantitative_data - apply(quantitative_data,2,mean))/apply(quantitative_data,2,var)
quantitative_data = log(quantitative_data)
quantitative_data = log(cbind(loan[,2:7],loan[,9:10]))
detec = as.matrix(t(quantitative_data))%*%as.matrix(quantitative_data)
cor(detec)>=0.8
cor
ev = eigen(detec)$val
max(ev)/min(ev)
quantitative_data%*%quantitative_data



                                  
                                  