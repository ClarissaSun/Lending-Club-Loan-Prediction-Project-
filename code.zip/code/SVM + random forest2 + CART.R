
# SVM 
ctrl <- trainControl(method="repeatedcv",
                     repeats=5,
                     summaryFunction=twoClassSummary,
                     classProbs=TRUE)
svm.tune <- train(x=train_data,
                  y=train_data$loan_outcome
                  method = "svmRadial",
                  tuneLength = 5,
                  preProc = c("center","scale"),
                  metric="ROC",
                  trControl=ctrl)
svm.tune
svm_model = ksvm(loan_status ~ .,
                 data = train_data,
                 kernel = "rbfdot",
                 kpar = list(sigma=0.003909534),
                 C = 0.1,
                 prob.model = TRUE,
                 scaled = FALSE)
predict_loan_status_svm = predict(svm_model,val_data,type="probabilities")
predict_loan_status_svm = as.data.frame(predict_loan_status_svm)$loan_outcome
rocCurve_svm = roc(response = test_data$loan_outcome,
                   predictor = predict_loan_status_svm)

auc_curve = auc(rocCurve_svm)
plot(rocCurve_svm,legacy.axes = TRUE,print.auc = TRUE,col="red",main="ROC(SVM)")

# random forest
rfGrid = expand.grid(
  .mtry = as.integer(seq(2,ncol(train_data), (ncol(train_data) - 2)/4))
)

rfTuned = train(
  train,
  y = samp[train_index_tuning,"loan_status"],
  method = "rf",
  tuneGrid = rfGrid,
  metric = "ROC",
  trControl = ctrl,
  preProcess = NULL,
  ntree = 100
)

plot(rfTuned)

rfTuned


# CART
library(caret)
data <- balanced.data
set.seed(430)
ctrl <- trainControl(method = "repeatedcv",
                     number = 10,
                     repeats = 3)
model <- train(
  form = loan_outcome~.,
  data=balanced.train_data,
  method = "rpart",
  trControl = ctrl)
model

trellis.par.set(caretTheme())
plot(model)
output_test=valid_data$loan_outcome

control <- rpart.control(minbucket = 20, cp = 0.0007464915, maxsurrogate = 0, usesurrogate = 0, xval = 10)
tr1 <- rpart(loan_outcome~.,
             data=train_data,
             method = "class",
             control = control)

tree.pred=predict(tr1,valid_data,type="class")
table(tree.pred,output_test)
rpart.plot(tr1,digits=4)
mean(tree.pred==output_test)

